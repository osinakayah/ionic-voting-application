<?php
require('includes/set_header.php');
require('includes/connect.php');
	
$postdata = file_get_contents("php://input");
if($postdata){
	$request = json_decode($postdata);
	
	$user_id = $request->user_id;
	$position_id = $request->position_id;
	$yr = date('Y');
	
	$stmt = "INSERT INTO elections(user_id, position_id, votes, is_closed, year) VALUES('$user_id', '$position_id', 0, 0, '$yr')";
	$res = mysqli_query($con, $stmt);
	if($res){
		$data['code'] = 1;
		$data['msg'] = "Success";
		echo json_encode($data);
	}
}
?>