<?php
require('includes/set_header.php');
require('includes/connect.php');

$stmt = "SELECT * FROM positions WHERE is_closed=0";
$res = mysqli_query($con, $stmt);
$data = array();
 if($res){
	while($row = mysqli_fetch_array($res)){
		$position = array();
		$position['id'] = $row['id'];
		$position['name'] = $row['name'];
		array_push($data, $position);
	}
	echo json_encode($data);
 }
?>