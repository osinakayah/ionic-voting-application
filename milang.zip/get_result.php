<?php
	require('includes/set_header.php');
	require('includes/connect.php');
	
	if(isset($_GET['pos'])){
	    $position_id = $_GET['pos'];
	    
	    $stmt = "SELECT u.firstname, u.lastname, e.id, e.votes FROM users u, elections e WHERE u.id = e.user_id AND e.position_id = '$position_id' ORDER BY votes DESC";
	    $res = mysqli_query($con, $stmt);
	    $data = array();
	    while($row = mysqli_fetch_array($res)){
	        $result = array();
	        $result['name'] = $row['firstname']." ".$row['lastname'];
	        $result['votes'] = $row['votes'];
	        array_push($data, $result);
	    }
	    echo json_encode($data);
	}
	
?>