<?php
require('includes/set_header.php');
require('includes/connect.php');
	
$postdata = file_get_contents("php://input");
if($postdata){
	$request = json_decode($postdata);
	
	$matric = $request->matric;
	$email = $request->email;
	$firstname = $request->firstname;
	$lastname = $request->lastname;
	$password = mt_rand();
	
	mail($email, "E-vote Password",$password);
	
	$stmt = "INSERT INTO users(matric, password, firstname, lastname, acc_type, email) VALUES('$matric', '$password', '$firstname', '$lastname', 2, '$email')";
	
	$res = mysqli_query($con, $stmt);
	if($res){
		$data['code'] = 1;
		$data['msg'] = "Registered Successfully";
		echo json_encode($data);
	}
	else{
		$data['code'] = 0;
		$data['msg'] = "Registered unsuccessfully";
		echo json_encode($data);
	}
}
?>