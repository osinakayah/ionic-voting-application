<?php
require('includes/set_header.php');
require('includes/connect.php');

$stmt = "SELECT * FROM positions";

$res = mysqli_query($con, $stmt);
$data = array();
if($res){
	while($row = mysqli_fetch_array($res)){
		$state['id'] = $row['id'];
		$state['is_closed'] = conv_to_boolean($row['is_closed']);
		array_push($data, $state);
	}
	echo json_encode($data);
}

function conv_to_boolean($state){
	if($state==1){
		return TRUE;
	}
	else if($state==0){
		return FALSE;
	}
}
?>