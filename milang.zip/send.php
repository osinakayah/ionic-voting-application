<?php
$email = "ifeanyiosinakayah15@gmail.com";
$r = mail($email, "E-vote Password","dff");
if($r){
    echo 1;
}
else{
    echo 0;
}
?>