<?php
	require('includes/set_header.php');
	require('includes/connect.php');
	
	$postdata = file_get_contents("php://input");
	
	if($postdata){
		$request = json_decode($postdata);
		$matric = $request->matric;
		$password = $request->password;
		
		$stmt = "SELECT * FROM users WHERE matric = '$matric' AND password = '$password'";
		$res = mysqli_query($con, $stmt);
		if($res){
			$num = mysqli_num_rows($res);
			if($num==1){
				$res = mysqli_fetch_array($res);
				$data['code'] = 1;
				$data['id'] = $res['id'];
				$data['msg'] = "Login Successfully";
				$data['name'] = $res['firstname']." ".$res['lastname'];
				$data['matric'] = $matric;
				$data['acc_type'] = $res['acc_type'];
				$data['email'] = $res['email'];
				echo json_encode($data);
			}
			else{
				$data['code'] = 0;
				$data['msg'] = "Incorrect username or password";
				echo json_encode($data);
			}
		}
		else{
			$data['code'] = 0;
			$data['msg'] = "Opps an error occured";
			echo json_encode($data);
		}
		
	}
	
	
	function get_firstname($id){
		require('includes/connect.php');
		$stmt = "SELECT firstname FROM users_tbl WHERE id = '$id'";
		$res = mysqli_query($con, $stmt);
		$res = mysqli_fetch_array($res);
		return $res['firstname'];
	}
?>