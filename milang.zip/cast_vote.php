<?php
require('includes/set_header.php');
require('includes/connect.php');
	
$postdata = file_get_contents("php://input");

if($postdata){
	
	$request = json_decode($postdata);
	if(isset($request->election_id)){
		$election_id = $request->election_id;
		
		$voter_id = $request->voter_id;
		
		if(is_election_closed($request->position_id)){
			$data['code'] = 0;
			$data['msg'] = "Election is closed";
			echo json_encode($data);
			exit();
		}
		if(is_voted($voter_id, $request->position_id)){
			$data['code'] = 0;
			$data['msg'] = "You are not allowed to vote twice. Thanks for voting";
			echo json_encode($data);
			exit();
		}
	
		
		
		$inc_count = get_num_votes($election_id);
		
		$stmt = "UPDATE elections SET votes = '$inc_count' WHERE id = '$election_id'";
		
		$res = mysqli_query($con, $stmt);
		
		if($res){
			has_voted($voter_id, $request->position_id);
			$data['code'] = 1;
			$data['msg'] = "Voted Successfully";
			echo json_encode($data);
		}
		else{
			$data['code'] = 0;
			$data['msg'] = "Oops an error occured";
			echo json_encode($data);
		}
	}
		
}

function get_num_votes($id){
	require('includes/connect.php');
	$stmt = "SELECT votes FROM elections WHERE id = '$id'";
	$res = mysqli_query($con, $stmt);
	$res = mysqli_fetch_array($res);
	
	$vote_num = $res['votes'];
	
	$vote_num++;
	return $vote_num;
}

function has_voted($user_id, $position_id){
	require('includes/connect.php');
	$stmt = "INSERT INTO position_voted_for(user_id, position_id) VALUES('$user_id', '$position_id')";
	mysqli_query($con, $stmt);
}

function is_election_closed($id){
	require('includes/connect.php');
	$stmt = "SELECT * FROM positions  WHERE id = '$id'";
	$res = mysqli_query($con, $stmt);
	$res = mysqli_fetch_array($res);
	if($res['is_closed'] == 1){
		return TRUE;
	}
	else{
		return FALSE;
	}
}

function is_voted($user_id, $position_id){
	require('includes/connect.php');
	$stmt = "SELECT * FROM position_voted_for WHERE user_id = '$user_id' AND position_id = '$position_id'";
	$res = mysqli_query($con, $stmt);
	$num = mysqli_num_rows($res);
	if($num>0){
		return TRUE;
	}
	return FALSE;
}
?>