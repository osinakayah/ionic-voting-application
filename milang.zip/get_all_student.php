<?php
require('includes/set_header.php');
require('includes/connect.php');

$stmt = "SELECT * FROM users";
$res = mysqli_query($con, $stmt);
$data = array();
 if($res){
	while($row = mysqli_fetch_array($res)){
		$student = array();
		$student['id'] = $row['id'];
		$student['matric'] = $row['matric'];
		$student['name'] = $row['firstname']." ".$row['lastname'];
		$student['email'] = $row['email'];
		
		array_push($data, $student);
	}
	echo json_encode($data);
 }

	
?>