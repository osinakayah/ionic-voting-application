<?php
require('includes/set_header.php');
require('includes/connect.php');
$position_id = $_GET['position_id'];
$state = $_GET['state'];

$stmt = "UPDATE positions SET is_closed = '$state' WHERE id = '$position_id'";


$res = mysqli_query($con, $stmt);
if($res){
	$data['code'] = 1;
	if($state==0){
		$data['msg'] = "Election has been started successfully";
	}
	else{
		$data['msg'] = "Election has been ended successfully";
	}
	echo json_encode($data);
}
else{
	$data['code'] = 0;
	$data['msg'] = "Ops an error occured";
	echo json_encode($data);
}

?>