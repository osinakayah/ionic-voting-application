<?php
require('includes/set_header.php');
require('includes/connect.php');


$position_id = $_GET['id'];



$stmt = "SELECT u.firstname, u.lastname, e.id FROM users u, elections e WHERE u.id = e.user_id AND e.position_id = '$position_id'";
//$stmt = "SELECT * FROM elections WHERE position_id = '$position_id'";
$res = mysqli_query($con, $stmt);
$data = array();
if($res){
	while($row = mysqli_fetch_array($res)){
		$aspirant['election_id'] = $row['id'];
		$aspirant['name'] = $row['firstname']." ".$row['lastname'];
		array_push($data, $aspirant);
	}
	echo json_encode($data);
}
	 

?>
