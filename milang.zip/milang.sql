-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jan 30, 2017 at 02:38 AM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 5.6.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `milang`
--

-- --------------------------------------------------------

--
-- Table structure for table `elections`
--

CREATE TABLE `elections` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `position_id` int(11) NOT NULL,
  `votes` int(11) NOT NULL,
  `is_closed` tinyint(4) NOT NULL,
  `year` varchar(4) NOT NULL,
  `winner` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `elections`
--

INSERT INTO `elections` (`id`, `user_id`, `position_id`, `votes`, `is_closed`, `year`, `winner`) VALUES
(1, 2, 1, 7, 1, '2016', 0),
(2, 5, 1, 3, 0, '2016', 0),
(3, 4, 2, 6, 0, '2016', 0),
(4, 7, 3, 5, 0, '2016', 0),
(5, 2, 0, 0, 0, '2016', 0),
(6, 9, 1, 1, 0, '2016', 0),
(7, 14, 2, 1, 0, '2017', 0),
(8, 11, 2, 0, 0, '2017', 0),
(9, 13, 3, 0, 0, '2017', 0),
(10, 15, 3, 0, 0, '2017', 0),
(11, 16, 4, 0, 0, '2017', 0),
(12, 17, 4, 0, 0, '2017', 0),
(13, 18, 4, 0, 0, '2017', 0);

-- --------------------------------------------------------

--
-- Table structure for table `positions`
--

CREATE TABLE `positions` (
  `id` int(11) NOT NULL,
  `name` varchar(32) NOT NULL,
  `is_closed` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `positions`
--

INSERT INTO `positions` (`id`, `name`, `is_closed`) VALUES
(1, 'President', 0),
(2, 'Vice President', 0),
(3, 'Treasurer', 0),
(4, 'Secretary', 0);

-- --------------------------------------------------------

--
-- Table structure for table `position_voted_for`
--

CREATE TABLE `position_voted_for` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `position_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `position_voted_for`
--

INSERT INTO `position_voted_for` (`id`, `user_id`, `position_id`) VALUES
(5, 8, 3),
(6, 8, 3),
(12, 8, 2),
(13, 9, 1),
(14, 8, 1),
(15, 2, 2);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `matric` varchar(32) NOT NULL,
  `password` varchar(255) NOT NULL,
  `firstname` varchar(32) NOT NULL,
  `lastname` varchar(32) NOT NULL,
  `acc_type` tinyint(4) NOT NULL,
  `email` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `matric`, `password`, `firstname`, `lastname`, `acc_type`, `email`) VALUES
(1, 'admin', 'admin', 'Milang', 'Dayo', 1, 'milangdayo@gmail.com'),
(2, 'osin', 'osin', 'Osinachi', 'ifeanyi', 2, 'ifeanyi@gmail.com'),
(4, 'david', 'david', 'David', 'Ogbeche', 2, 'davidogbeche@gmail.com'),
(5, 'victor', 'victor', 'Victor', 'Ohambele', 2, 'victor@gmail.com'),
(7, 'steve', 'steve', 'Stephen', 'Okechukwu', 2, 'stephen@gmail.com'),
(8, 'ossy', 'ossy', 'Joseph', 'Michael', 2, 'osi@gmail.com'),
(9, 'debby', 'debby', 'Deborah', 'Folake', 2, 'debi@gmail.com'),
(10, 'mouau/11/17796', 'mouau', 'Osinakayah', 'Ifeanyi', 2, 'ifeanyiosinakayah15@gmail.com'),
(11, 'chris', 'chris', 'Chris', 'James', 2, 'chrisjames@gmail.com'),
(12, 'chinedu', 'chinedu', 'Chinedu', 'Sunday', 2, 'chinedusunday@gnail.vom'),
(13, 'good', 'good', 'Goodluck', 'Allen', 2, 'goodluck@gmail.com'),
(14, 'emeka', '1984754702', 'Emeka', 'Uche', 2, 'emeka@gmail.com'),
(15, 'hope', '1469659250', 'Hope', 'Stephen', 2, 'hope@gmail.com'),
(16, 'prince', '713369996', 'Prince', 'Azuonye', 2, 'prince@gmail.com'),
(17, 'ebere', '1257405874', 'Chidiebere', 'Onyedinma', 2, 'ebere@gmail.com'),
(18, 'zubix', '2008187408', 'Izuchukwu', 'Azuibike', 2, 'zubix@gmail.com'),
(19, 'bolt', '1208042442', 'Fortune', 'Chibueze', 2, 'bolt@gmail.com'),
(20, 'jane', '1962979425', 'Jane', 'Arisah', 2, 'jane@gmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `elections`
--
ALTER TABLE `elections`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `positions`
--
ALTER TABLE `positions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `position_voted_for`
--
ALTER TABLE `position_voted_for`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `matric` (`matric`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `elections`
--
ALTER TABLE `elections`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `positions`
--
ALTER TABLE `positions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `position_voted_for`
--
ALTER TABLE `position_voted_for`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
