<?php
$host = "127.0.0.1";
$username = "root";
$password = "";
$db = "milang";
$port = 3306;

$con = mysqli_connect($host, $username, $password, $db, $port);

?>